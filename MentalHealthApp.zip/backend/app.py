
from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token
from flask_cors import CORS
from datetime import datetime, timedelta
import tensorflow as tf
import numpy as np

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Configurations
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mental_health.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'your_jwt_secret_key'
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)

# User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

# Mood Log Model
class MoodLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    mood = db.Column(db.String(50), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# Initialize database
db.create_all()

# Routes
@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    hashed_password = bcrypt.generate_password_hash(data['password']).decode('utf-8')
    new_user = User(username=data['username'], email=data['email'], password=hashed_password)
    db.session.add(new_user)
    db.session.commit()
    return jsonify({'message': 'User registered successfully'}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    user = User.query.filter_by(email=data['email']).first()
    if user and bcrypt.check_password_hash(user.password, data['password']):
        access_token = create_access_token(identity={'username': user.username, 'email': user.email})
        return jsonify({'access_token': access_token}), 200
    return jsonify({'message': 'Invalid credentials'}), 401

@app.route('/log_mood', methods=['POST'])
def log_mood():
    data = request.get_json()
    new_log = MoodLog(user_id=data['user_id'], mood=data['mood'])
    db.session.add(new_log)
    db.session.commit()
    return jsonify({'message': 'Mood logged successfully'}), 201

@app.route('/mood_logs/<int:user_id>', methods=['GET'])
def get_mood_logs(user_id):
    logs = MoodLog.query.filter_by(user_id=user_id).all()
    result = [{'mood': log.mood, 'timestamp': log.timestamp} for log in logs]
    return jsonify(result), 200

# AI-Based Mood Prediction
@app.route('/predict_mood', methods=['POST'])
def predict_mood():
    data = request.get_json()
    model_input = np.array(data['inputs']).reshape(1, -1)
    mock_model_output = [0.7]
    predicted_mood = "Happy" if mock_model_output[0] > 0.5 else "Neutral"
    return jsonify({'predicted_mood': predicted_mood}), 200

# Therapist Booking
@app.route('/book_therapist', methods=['POST'])
def book_therapist():
    data = request.get_json()
    return jsonify({'message': f"Therapist {data['therapist_name']} booked successfully for {data['appointment_time']}"}), 201

# Community Support Chat (Placeholder for real-time chat functionality)
@app.route('/community_chat', methods=['GET'])
def community_chat():
    return jsonify({'message': 'Community chat feature coming soon!'}), 200

# Main execution
if __name__ == '__main__':
    app.run(debug=True)
